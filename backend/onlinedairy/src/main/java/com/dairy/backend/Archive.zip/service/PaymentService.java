package com.dairy.backend.service;

import com.dairy.backend.exception.FarmerNotFoundException;
import com.dairy.backend.model.Farmer;
import com.dairy.backend.model.MilkRequest;
import com.dairy.backend.model.Payment;
import com.dairy.backend.model.TransactionType;
import com.dairy.backend.repository.FarmerRepository;
import com.dairy.backend.repository.PaymentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private FarmerRepository farmerRepository;

    // Create a payment record when an employee approves the milk request
//    @Transactional
//    public Payment createPayment(MilkRequest request) {
//        double amount = request.getLiters() * request.getPricePerLiter();
//
//        // Update Farmer's Wallet Money
//        Farmer farmer = farmerRepository.findByName(request.getFarmerName())
//                .orElseThrow(() -> new RuntimeException("Farmer not found"));
//
//        farmer.setWalletMoney(farmer.getWalletMoney() + amount);
//        farmerRepository.save(farmer);
//
//        // Create and Save Payment Record
//        Payment payment = new Payment();
//        payment.setMilkRequestId(request.getId());
//        payment.setFarmerName(request.getFarmerName());
//        payment.setAmount(amount);
//        payment.setPaymentDate(LocalDateTime.now());
//        payment.setTransactionType(TransactionType.CREDIT); // Mark as CREDIT
//
//        return paymentRepository.save(payment);
//    }

    @Transactional
    public Payment createPayment(MilkRequest request) {
        // Get the farmer directly from the request
        Farmer farmer = request.getFarmer();

        // Calculate payment amount
        double amount = request.getLiters() * request.getPricePerLiter();

        // Update farmer's wallet
        farmer.setWalletMoney(farmer.getWalletMoney() + amount);
        farmerRepository.save(farmer);

        // Create payment record
        Payment payment = new Payment();
        payment.setMilkRequestId(request.getId());
        payment.setFarmerName(farmer.getName()); // Optional: Keep farmer name for reporting
        payment.setAmount(amount);
        payment.setTransactionType(TransactionType.CREDIT);
        payment.setPaymentDate(LocalDateTime.now());
        return paymentRepository.save(payment);
    }

    // Retrieve all payments for a farmer
    public List<Payment> findPaymentsByFarmer(String farmerName) {
        return paymentRepository.findByFarmerName(farmerName);
    }

    // Get the total wallet balance of a farmer
    public double getFarmerWalletBalance(String farmerName) {
        Farmer farmer = farmerRepository.findByName(farmerName)
                .orElseThrow(() -> new RuntimeException("Farmer not found"));
        return farmer.getWalletMoney();
    }

    // Debit money from farmer's wallet (Only if bank details exist)
//    @Transactional
    public Payment debitMoney(String farmerName, double amount) {
        Farmer farmer = farmerRepository.findByName(farmerName)
                .orElseThrow(() -> new RuntimeException("Farmer not found"));

        // Validate if bank details exist
        if (farmer.getBankDetails() == null || !farmer.getBankDetails().containsKey("accountNumber")) {
            throw new UnauthorizedException("Bank details missing. Add your bank details before withdrawal.");
        }

        if (farmer.getWalletMoney() < amount) {
            throw new RuntimeException("Insufficient balance in wallet.");
        }

        // Deduct money from wallet
        farmer.setWalletMoney(farmer.getWalletMoney() - amount);
        farmerRepository.save(farmer);

        // Record DEBIT transaction
        Payment debitTransaction = new Payment();
        debitTransaction.setFarmerName(farmerName);
        debitTransaction.setAmount(amount);
        debitTransaction.setPaymentDate(LocalDateTime.now());
        debitTransaction.setTransactionType(TransactionType.DEBIT); // Mark as DEBIT

        return paymentRepository.save(debitTransaction);
    }

    // Get all transactions (Credits & Debits) sorted by date
    public List<Payment> getAllTransactions(String farmerName) {
        return paymentRepository.findByFarmerNameOrderByPaymentDateDesc(farmerName);
    }
    public String getAuthenticatedFarmer() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof UserDetails) {
            return ((UserDetails) principal).getUsername();
        } else {
            throw new RuntimeException("Authentication error: No valid farmer found.");
        }
    }

}
