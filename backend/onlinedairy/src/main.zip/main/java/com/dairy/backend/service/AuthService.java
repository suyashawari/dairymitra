package com.dairy.backend.service;

import com.dairy.backend.dto.FarmerSignupDTO;
import com.dairy.backend.model.AppUser;
import com.dairy.backend.repository.AppUserRepository;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
//
//@Service
//public class AuthService {
//
//    private final AppUserRepository userRepository;
//    private final PasswordEncoder passwordEncoder;
//
//    public AuthService(AppUserRepository userRepository, PasswordEncoder passwordEncoder) {
//        this.userRepository = userRepository;
//        this.passwordEncoder = passwordEncoder;
//    }
//
//
//    public String signup(AppUser user, String role) {
//        AppUser existingUser = userRepository.findByUsername(user.getUsername());
//        if (existingUser != null) {
//            throw new RuntimeException("User already exists");
//        }
//        user.setRole(role);
//        user.setPassword(passwordEncoder.encode(user.getPassword()));
//        userRepository.save(user);
//        return role + " signed up successfully!";
//    }
//
//    public Authentication validateUser(String username, String password) {
//        AppUser user = userRepository.findByUsername(username);
//        if (user == null) {
//            throw new RuntimeException("User not found");
//        }
//        if (!passwordEncoder.matches(password, user.getPassword())) {
//            throw new RuntimeException("Incorrect password");
//        }
//        List<GrantedAuthority> authorities = Collections.singletonList(
//                new SimpleGrantedAuthority(user.getRole())
//        );
//        return new UsernamePasswordAuthenticationToken(username, password, authorities);
//    }
//}

// ... existing imports ...
import com.dairy.backend.model.Farmer;
import com.dairy.backend.repository.FarmerRepository;

@Service
public class AuthService {

    private final AppUserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final FarmerRepository farmerRepository; // Added

    public AuthService(AppUserRepository userRepository, PasswordEncoder passwordEncoder, FarmerRepository farmerRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.farmerRepository = farmerRepository; // Added
    }

    public String signup(AppUser user, String role) {
        AppUser existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser != null) {
            throw new RuntimeException("User already exists");
        }
        user.setRole(role);
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);

        if ("FARMER".equalsIgnoreCase(role)) {
            Farmer farmer = new Farmer(user.getUsername());
            farmerRepository.save(farmer);
        }

        return role + " signed up successfully!";
    }
    public Authentication validateUser(String username, String password) {
        AppUser user = userRepository.findByUsername(username);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Incorrect password");
        }
        List<GrantedAuthority> authorities = Collections.singletonList(
                new SimpleGrantedAuthority(user.getRole())
        );
        return new UsernamePasswordAuthenticationToken(username, password, authorities);
    }
    public String signupFarmerWithDetails(FarmerSignupDTO signupRequest) {
        AppUser existingUser = userRepository.findByUsername(signupRequest.getUsername());
        if (existingUser != null) {
            throw new RuntimeException("User already exists");
        }

        // Create AppUser
        AppUser user = new AppUser();
        user.setUsername(signupRequest.getUsername());
        user.setPassword(passwordEncoder.encode(signupRequest.getPassword()));
        user.setRole("ROLE_FARMER");
        userRepository.save(user);

        // Create Farmer with Bank Details
        Farmer farmer = new Farmer(signupRequest.getUsername());
        farmer.setBankDetails(signupRequest.getBankDetails());
        farmerRepository.save(farmer);

        return "Farmer signed up successfully!";
    }
    // ... rest of the code ...
}