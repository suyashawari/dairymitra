//package com.dairy.backend.model;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import lombok.Data;
//
//
//@Entity
//    @Data
//    public class MilkRequest {
//
//        @Id
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
//        private Long id;
//
//        private double liters;
//        private double fatPercentage;
//        private double proteinPercentage;
//        private double waterContent;
//        private double pricePerLiter;
//
//        // Request status: PENDING, APPROVED, or REJECTED
//        private String status;
//
//        private String farmerName; // Simple field to identify the farmer
//
//        // Constructors, getters, and setters
//        public MilkRequest() {}
//
//        public MilkRequest(String farmerName, double liters, double fatPercentage, double proteinPercentage, double waterContent) {
//            this.farmerName = farmerName;
//            this.liters = liters;
//            this.fatPercentage = fatPercentage;
//            this.proteinPercentage = proteinPercentage;
//            this.waterContent = waterContent;
//            this.status = "PENDING";
//        }
//
//        // Getters and setters below
//
//
//    }


package com.dairy.backend.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MilkRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double liters;
    private double fatPercentage;
    private double proteinPercentage;
    private double waterContent;
    private double pricePerLiter;

    // Request status: PENDING, APPROVED, or REJECTED
    private String status;
    @ManyToOne
    @JoinColumn(name = "farmer_id")
    private Farmer farmer;// Simple field to identify the farmer

    // Constructors, getters, and setters



    // Getters and setters below


}


