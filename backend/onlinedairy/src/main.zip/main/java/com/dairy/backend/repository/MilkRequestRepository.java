package com.dairy.backend.repository;
import com.dairy.backend.model.MilkRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MilkRequestRepository extends JpaRepository<MilkRequest, Long> {
    List<MilkRequest> findByFarmerName(String farmerName);

    List<MilkRequest> findByStatus(String status);
}
