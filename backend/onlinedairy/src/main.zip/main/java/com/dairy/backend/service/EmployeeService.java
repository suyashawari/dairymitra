package com.dairy.backend.service;
import com.dairy.backend.model.MilkRequest;
import com.dairy.backend.repository.MilkRequestRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private MilkRequestRepository milkRequestRepository;

    @Autowired
    private PaymentService paymentService;

    // Get all pending milk requests for verification.
    public List<MilkRequest> getPendingRequests() {
        return milkRequestRepository.findByStatus("PENDING");
    }

    // Approve a milk request and create a corresponding payment.

//    public MilkRequest approveRequest(Long id) throws Exception {
//        Optional<MilkRequest> opt = milkRequestRepository.findById(id);
//        if (opt.isPresent()) {
//
//            System.out.println(opt.toString());
//            MilkRequest request = opt.get();
//            request.setStatus("APPROVED");
//            MilkRequest updated = milkRequestRepository.save(request);
//
//            // Create payment for the approved request.
//            paymentService.createPayment(updated);
//            return updated;
//        } else {
//            System.out.println(opt.toString());
//            throw new Exception("Request not found");
//        }
//    }
//@Transactional
@Transactional
public MilkRequest approveRequest(Long id) throws Exception {
    Optional<MilkRequest> opt = milkRequestRepository.findById(id);
    if (!opt.isPresent()) {
        throw new Exception("Request not found");
    }

    MilkRequest request = opt.get();
    if (request.getFarmer() == null) {
        throw new Exception("Milk request has no associated farmer");
    }

    request.setStatus("APPROVED");
    MilkRequest updated = milkRequestRepository.save(request);

    // Trigger payment creation
    paymentService.createPayment(updated);

    return updated;
}


    // Reject a milk request.
    public MilkRequest rejectRequest(Long id) throws Exception {
        Optional<MilkRequest> opt = milkRequestRepository.findById(id);
        if (opt.isPresent()) {
            MilkRequest request = opt.get();
            request.setStatus("REJECTED");
            return milkRequestRepository.save(request);
        } else {
            throw new Exception("Request not found");
        }
    }
}
