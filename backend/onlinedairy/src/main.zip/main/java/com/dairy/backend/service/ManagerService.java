package com.dairy.backend.service;

import com.dairy.backend.model.MilkRequest;
import com.dairy.backend.repository.MilkRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManagerService {

    @Autowired
    private MilkRequestRepository milkRequestRepository;

    // For simplicity, a manager can get an overview report of milk requests
    public List<MilkRequest> getAllMilkRequests() {
        return milkRequestRepository.findAll();
    }

    // Additional reporting methods (e.g., employee performance, quality trends) can be added here.
}
